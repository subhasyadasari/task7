package com.task7.design_patterns.design_patterns;

public class Application {

    public static void main(String[] args) {
        System.out.println("Hello design_patterns");
    }

}