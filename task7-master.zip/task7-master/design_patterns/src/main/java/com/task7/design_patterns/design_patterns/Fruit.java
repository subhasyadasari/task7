package com.task7.design_patterns.design_patterns;

public interface Fruit {
	
	void buy();
	
}
