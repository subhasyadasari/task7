package com.task7.design_patterns.design_patterns;

public class Banana implements Fruit {
	@Override
	   public void buy() {
	      System.out.println("Inside Banana::buy() method.");
	   }
}