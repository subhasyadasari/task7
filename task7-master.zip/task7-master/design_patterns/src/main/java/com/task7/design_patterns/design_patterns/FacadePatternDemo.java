package com.task7.design_patterns.design_patterns;

public class FacadePatternDemo {
	   public static void main(String[] args) {
	      FruitSelect fruitSelect = new FruitSelect();

	      fruitSelect.buyApple();
	      fruitSelect.buyBanana();
	      fruitSelect.buyMango();
	      
	   }
	}
