package com.task7.design_patterns.design_patterns;

public class Apple implements Fruit {
	@Override
	   public void buy() {
	      System.out.println("Inside Apple::buy() method.");
	   }
}
