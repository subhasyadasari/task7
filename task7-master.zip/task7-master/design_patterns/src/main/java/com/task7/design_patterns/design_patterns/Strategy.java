package com.task7.design_patterns.design_patterns;

public interface Strategy {
	   public int doOp(int n1, int n2);
}