package com.task7.design_patterns.design_patterns;

public class sub implements Strategy{
		   @Override
		   public int doOp(int n1,int n2) {
		      return n1-n2;
		   }

}
