package com.task7.design_patterns.design_patterns;

public class Mango implements Fruit {
	@Override
	   public void buy() {
	      System.out.println("Inside Mango::buy() method.");
	   }
}