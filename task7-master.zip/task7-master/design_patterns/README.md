## design_patterns Java Project
